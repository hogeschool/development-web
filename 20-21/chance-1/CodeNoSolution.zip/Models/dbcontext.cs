using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SimpleModelsAndRelations.Models
{
    public class Mother
    {
        //TODO 3 [0.25pt]
        //...
        public int SSN { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }

        //TODO 4 [0.5pt]
        //...
    }
    public class Child
    {
        //TODO 5 [0.25pt]
        //...
        public int SSN { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        
        //TODO 2 [0.5pt]
        //...

    }

    public partial class SimpleModelsAndRelationsContext : DbContext
    {
        //TODO 1 [1pt]
        //...
        public SimpleModelsAndRelationsContext(DbContextOptions<SimpleModelsAndRelationsContext> options) : base(options) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }

    }
}
