import * as React from 'react'
import { RouteComponentProps } from "react-router";
import { Child, Mother } from '../types';

export let MotherFC : React.FunctionComponent<Mother> = (m) => {
  return <div>
    <div>FullName: {m.Name} {m.Surname}</div>
    <div>Age: {m.Age}</div>
    <div>SSN: {m.SSN}</div>
  </div>
}

export let ChildFC : React.FunctionComponent<Child> = (m) => {
  return <div style={{border:"dotted"}}>
    <div>FullName: {m.Name} {m.Surname}</div>
    <div>Age: {m.Age}</div>
    <div>SSN: {m.SSN}</div>
  </div>
}