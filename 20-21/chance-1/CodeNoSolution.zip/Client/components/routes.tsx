import * as React from 'react';
import { Route } from 'react-router-dom';
import { Layout } from './Layout';
import { FamiliesComponent } from './FamiliesComponent';

export const routes = <Layout>
    <Route exact path='/'component={ FamiliesComponent } />
    <Route path='/:slug' render={_ => <div>Not found</div>} />
</Layout>;
