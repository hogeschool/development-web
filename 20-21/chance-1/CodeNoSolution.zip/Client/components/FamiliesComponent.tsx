import * as React from 'react'
import { Mother, Child, Families } from '../types';
import { Map } from 'immutable'
import { ChildFC, MotherFC } from '../containers/FamiliesContainers';



export type FamiliesComponentState = {
  families: { kind: "loaded", families: Families } | { kind: "loading" } | { kind: "error-or-not-found" } | { kind: "none" }
}
export type FamiliesComponentProps = {}


//TODO 12 [0.5pt]
export class FamiliesComponent extends //...

  constructor(props: FamiliesComponentProps) {
    super(props)
    //TODO 13 [0.5pt]
    //...
  }

  getFamilies() {
    this.setState(s => ({ ...s, families: { kind: "loading" } }), () => {

      let headers = { 'content-type': 'application/json' }

      //TODO 14 [1pt]
      //...
        .then(async res => {


          try {
            if (!res.ok)
              this.setState(s => ({ ...s, families: { kind: "error-or-not-found" } }))
            
            let res1 = await res.json()
            
            //TODO 15 [1pt]            
            //...
          }
          catch {
            //TODO 16 [0.5pt]            
            //...
          }
        })
    })
  }

  componentWillMount() {
    this.getFamilies()
  }
  //TODO 17 [0.25pt]            
  public //...

    if (this.state.families.kind != "loaded") {
      return <p>{this.state.families.kind}</p>
    }


    return <div className='container-fluid row'>
      <div className="row">
        <div className='col-sm-6'>
          <h2>Families</h2>

          {/* 
          //TODO 18 [1.25pt] 
          */}
          {/* 
            //...
          )} */}
        </div>
      </div>
    </div>
  }
}