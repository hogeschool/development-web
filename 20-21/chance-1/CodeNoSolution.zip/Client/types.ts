export type Families = Mother[]


export type Child = {
    Id: number,
    Name: string,
    Surname: string,
    SSN: number,
    Age: number,
    MotherId: number
}
export type Mother = {
    Id: number,
    Name: string,
    Surname: string,
    SSN: number,
    Age: number,
    Children: Child[]
}