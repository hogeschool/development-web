using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SimpleModelsAndRelations.Models;



namespace SimpleModelsAndRelations.Controllers
{

    //TODO 11 [0.25pt]
    //...
    public partial class FamilyController : Controller
    {
        private readonly SimpleModelsAndRelationsContext _context;
        private readonly ProjectNameOptions _projectNameOptions;


        public FamilyController(SimpleModelsAndRelationsContext context, IOptions<ProjectNameOptions> projectNameOptions)
        {
            _context = context;
            _projectNameOptions = projectNameOptions.Value;
            if (_context.Mothers.Count() == 0)
            {
                _context.Mothers.AddRange(new Mother[]{
                    new Mother(){Age=51, SSN=3829, Name="Maria", Surname="Giove", Children=new List<Child>(){
                        new Child(){Name="Jack", Surname="Doe", Age=21, SSN=4718},
                        new Child(){Name="Nick", Surname="Doe", Age=18, SSN=9371}
                    }},
                    new Mother(){Age=39, SSN=4918, Name="Carla", Surname="Bruni", Children=new List<Child>(){
                        new Child(){Name="Sara", Surname="Jackson", Age=10, SSN=7462},
                        new Child(){Name="Tim", Surname="Jackson", Age=8, SSN=3948}
                    }}
                });
                _context.SaveChanges();
            }
        }

        [HttpPost("AddMother/{name}/{surname}/{age}/{ssn}")]
        //TODO 6 [0.25pt]
        //...
        {
            if (_context.Mothers.FirstOrDefault(m => m.SSN == ssn) != null)
                return Unauthorized();


            //TODO 7 [1pt]
            //...

            return Ok();
        }

        //TODO 8 [0.25pt]
        //...
        public IActionResult AddChild([FromBody] Child child, int mother_ssn)
        {
            var mother = _context.Mothers.FirstOrDefault(m => m.SSN == mother_ssn);
            if (_context.Children.FirstOrDefault(c => c.SSN == child.SSN) != null || mother == null)
                return Unauthorized();

            var new_child = new Child() { Age = child.Age, MotherId = mother.Id, Name = child.Name, SSN = child.SSN, Surname = child.Surname };
            _context.Children.Add(new_child);
            return Ok();
        }

        [HttpGet("GetAllFamilies")]
        public IActionResult GetAllFamilies()
        {
            var families_grouped = (
                                    //TODO 9 [0.5pt]
                                    //...
                                    select new { Mother = m, Child = c }).ToArray();


            var families_grouped_transformed = new Dictionary<int, Tuple<Mother, List<Child>>>();

            foreach (var item in families_grouped)
            {
                item.Mother.Children = null;
                item.Child.Mother = null;
                if (!families_grouped_transformed.ContainsKey(item.Mother.Id))
                {
                    families_grouped_transformed.Add(item.Mother.Id, Tuple.Create(item.Mother, new List<Child>()));
                }
                families_grouped_transformed[item.Mother.Id].Item2.Add(item.Child);
            }

            var res = families_grouped_transformed.Select(x => new { Mother = x.Value.Item1, Children = x.Value.Item2 });
            //TODO 10 [0.25pt]
            //...
        }
    }
}
