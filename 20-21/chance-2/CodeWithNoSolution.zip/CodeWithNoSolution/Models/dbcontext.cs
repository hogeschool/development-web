using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SimpleModelsAndRelations.Models
{
    public class VendingMachine
    {
        public int Id { get; set; }
        public string Location { get; set; }

        //TODO 1: 0.5
        //...
    }
    public class Coin
    {
        public int Id { get; set; }
        public double CoinPrice { get; set; }
        public int Count { get; set; }
        
        //TODO 2: 0.5
        //...
    }

    public class Product
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public double ProductPrice { get; set; }
        public int Count { get; set; }

        //TODO 3: 0.5
        //...
    }

    public partial class SimpleModelsAndRelationsContext : DbContext
    {
        //TODO 4: 0.5
        //...
        public DbSet<VendingMachine> VendingMachines { get; set; }

        public SimpleModelsAndRelationsContext(DbContextOptions<SimpleModelsAndRelationsContext> options) : base(options) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }

    }
}
