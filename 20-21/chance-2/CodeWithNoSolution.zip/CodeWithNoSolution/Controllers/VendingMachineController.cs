using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SimpleModelsAndRelations.Models;



namespace SimpleModelsAndRelations.Controllers
{
    public class BuyProductProps
    {
        public int VendingMachineId { get; set; }
        public Product Product { get; set; }
        public Coin[] Coins { get; set; }
    }


    //TODO 5 [0.5pt]
    //...
    public partial class VendingMachineController : Controller
    {
        private readonly SimpleModelsAndRelationsContext _context;
        private readonly ProjectNameOptions _projectNameOptions;


        public VendingMachineController(SimpleModelsAndRelationsContext context, IOptions<ProjectNameOptions> projectNameOptions)
        {
            _context = context;
            _projectNameOptions = projectNameOptions.Value;
            if (_context.VendingMachines.Count() == 0)
            {
                _context.VendingMachines.AddRange(new VendingMachine[]{
                    new VendingMachine(){
                        Location = "HRO-Wijnhaven",
                        Coins=new List<Coin>(){
                            new Coin(){CoinPrice=2, Count=15},
                            new Coin(){CoinPrice=0.50, Count=35}
                    },
                    Products = new List<Product>(){
                            new Product(){ProductPrice=0.99, Count=9, ProductName="Mars"},
                            new Product(){ProductPrice=1.2, Count=10, ProductName="RedBull"}
                    }},
                    new VendingMachine(){
                        Location = "Inholland-Haarlem",
                        Coins=new List<Coin>(){
                            new Coin(){CoinPrice=1, Count=40},
                    },
                    Products = new List<Product>(){
                            new Product(){ProductPrice=1, Count=20, ProductName="Water"},
                            new Product(){ProductPrice=1.2, Count=10, ProductName="RedBull"}
                    }},
                });
                _context.SaveChanges();
            }
        }

        [HttpPost("BuyProduct")]
        //TODO 6 [0.5pt]
        //...
        {
            //this method takes care of registering a product buy transaction


            var vending_machine_in_db = _context.VendingMachines.FirstOrDefault(v => v.Id == props.VendingMachineId);
            if (vending_machine_in_db == null)
            {
                return Ok("vending machine not found");
            }
            var product_in_db = _context.Products.FirstOrDefault(p => p.Id == props.Product.Id);
            if (product_in_db == null)
            {
                return Ok("product not found");
            }


            //update the product counter in the db
            product_in_db.Count -= props.Product.Count;
            _context.Update(product_in_db);

            var coins_in_db = (from c in _context.Coins
                               let c1 = props.Coins.FirstOrDefault(c1 => c1.CoinPrice == c.CoinPrice)
                               where c.VendingMachineId == vending_machine_in_db.Id && c1 != null
                               select Tuple.Create(c, c1)).ToList();
            
            //coins not in bs are kind of coins that are yet to be added to this vending machine
            var coins_not_in_db =   //TODO 7 [1pt]
                                    //...

            //update existing coins counter
            foreach (var coin_in_db in coins_in_db)
            {
                coin_in_db.Item1.Count += coin_in_db.Item2.Count;
                _context.Coins.Update(coin_in_db.Item1);
            }

            //register the new coins
            //TODO 8 [1pt]
            //...



            return Ok("transaction registered");
        }

        [HttpGet("GetAllProducts")]
        public IActionResult GetAllProducts()
        {
            var vending_machines_grouped = (
                                    from m in _context.VendingMachines
                                    let products = (from p in _context.Products
                                                    where p.VendingMachineId == m.Id
                                                    select new Product(){Count=p.Count, ProductName = p.ProductName, ProductPrice = p.ProductPrice, Id = p.Id})
                                    let coins = (from c in _context.Coins
                                                    where c.VendingMachineId == m.Id
                                                    select new Coin(){CoinPrice=c.CoinPrice, Count = c.Count, Id = c.Id})
                                    select new { VendingMachine = m, Coins = coins.ToArray(), Products = products.ToArray() }).ToArray();
            return Ok(vending_machines_grouped);
        }
    }
}
