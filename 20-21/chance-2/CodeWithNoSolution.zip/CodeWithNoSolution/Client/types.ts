export type VendingMachines = VendingMachine[]


export type VendingMachine = {
    Id: number,
    Location: string,
    Coins: Coin[],
    Products: Product[]
}
export type Coin = {
    Id: number,
    Count: number,
    CoinPrice: number
}
export type Product = {
    Id: number,
    ProductName: string,
    ProductPrice: number,
    Count: number
}