import * as React from 'react'
import { VendingMachine, VendingMachines } from '../types'
import { CoinFC, ProductFC, VendingMachineFC } from '../containers/VendingMachineContainers'



//TODO 9 [1pt]
//...
export type VendingMachinesComponentProps = {}


export class VendingMachinesComponent extends React.Component<VendingMachinesComponentProps, VendingMachinesComponentState> {

  constructor(props: VendingMachinesComponentProps) {
    super(props)
    this.state = {
      vendingMachines: { kind: "none" }
    }
  }

  getVendingMachines() {

    //note: when downloading the data we first set the 'machines' attribute to loading and then we fetch them from the db
    this.setState(
      
      //TODO 10 [1pt]
      //...setState...

      () => {
        
        
        let headers = { 'content-type': 'application/json' }
        //TODO 11 [1pt]
        //...
        .then(async res => {


          try {
            if (!res.ok)
              this.setState(s => ({ ...s, vendingMachines: { kind: "error-or-not-found" } }))
            
            let res1 = await res.json()
            
            let vendingMachines: VendingMachines = []
            vendingMachines = res1.map((item): VendingMachine => {
              return { ...item.VendingMachine, Coins: item.Coins, Products: item.Products }
            })
            this.setState(s => ({ ...s, vendingMachines: { kind: "loaded", vendingMachines: vendingMachines } }))
          }
          catch {
            this.setState(s => ({ ...s, vendingMachines: { kind: "error-or-not-found" } }))
          }
        })
    })
  }

  componentWillMount() {
    this.getVendingMachines()
  }
  public render() {

    if (this.state.vendingMachines.kind != "loaded") {
      return <p>{this.state.vendingMachines.kind}</p>
    }


    return <div className='container-fluid row'>
      <div className="row">
        <div className='col-sm-6'>
          <h2>VendingMachines</h2>
          {/* Note. Use the Function components to render each vending machine and its relations */}

          
          {/* TODO 12 [0.5pt] */}
          {/* ... */}
            <div style={{ border: "solid" }}>
              {/* TODO 13 [0.5pt] */}
              {/* ... */}
              <div>
                Coins:
                <div style={{ paddingLeft: 10 }}>
                  {/* TODO 14 [0.5pt] */}
                  {/* ... */}
                </div>
              </div>
              <div>
                Products:
                <div style={{ paddingLeft: 10 }}>
                  {/* TODO 15 [0.5pt] */}
                  {/* ... */}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  }
}