import * as React from 'react'
import { RouteComponentProps } from "react-router";
import { Coin, Product, VendingMachine } from '../types';

export let VendingMachineFC : React.FunctionComponent<VendingMachine> = (m) => {
  return <div>
    <div>Id: {m.Id}</div>
    <div>Location: {m.Location}</div>
  </div>
}

export let CoinFC : React.FunctionComponent<Coin> = (m) => {
  return <div style={{border:"dotted"}}>
    <div>CoinPrice: {m.CoinPrice}</div>
    <div>Count: {m.Count}</div>
  </div>
}


export let ProductFC : React.FunctionComponent<Product> = (m) => {
  return <div style={{border:"dotted"}}>
    <div>ProductName: {m.ProductName}</div>
    <div>ProductPrice: {m.ProductPrice}</div>
    <div>Count`: {m.Count}</div>
  </div>
}