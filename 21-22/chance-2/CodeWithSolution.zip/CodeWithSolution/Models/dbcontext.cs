using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SimpleModelsAndRelations.Models
{
    public class PC
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Price { get; set; }
        //TODO 1 [0.5pt]: A pc is in a relationship 1-N with component
        // ...
    }
    public class Component
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string Kind { get; set; }
        public string Specification { get; set; }
        //TODO 2 [0.5pt]: A pc is in a relationship 1-N with component
        // ...
    }


    public partial class ComputerShopContext : DbContext
    {
        //TODO 3 [1pt]: our database contains two tables: PC and Component
        // ...

        public ComputerShopContext(DbContextOptions<ComputerShopContext> options) : base(options) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }

    }
}
