
export type Component = {
    Id: number,
    Brand: string,
    Kind: string,
    Specification: string
}
export type PC = {
    Id: number,
    Brand: string,
    Model: string,
    Price: number
}

export type PC_Components = {
    PC: PC,
    Components: Component[]
}