import * as React from 'react'
import { RouteComponentProps } from "react-router";
import { PC, Component } from '../types';

export let PCRenderer : React.FunctionComponent<PC> = (m) => {
  return <div>
    <div>Brand: {m.Brand}</div>
    <div>Model: {m.Model}</div>
    <div>Price: {m.Price}</div>
  </div>
}


// TODO 12 [1pt]: render all details of a component
export let ComponentRenderer // ...
