import * as React from 'react'
import { PC_Components, PC, Component } from '../types';
import { Map } from 'immutable'
import { PCRenderer, ComponentRenderer } from '../containers/ComputerShopContainers';
import { Set } from "immutable"


export type ComputerShopComponentState = {
  computerShop: { kind: "loaded", value: PC_Components[] } | { kind: "loading" } | { kind: "error-or-not-found" } | { kind: "none" }
}
export type ComputerShopProps = {}

                                   // TODO 7 [1pt]: ComputerShopComponent is a react component. Complete the signature.
export class ComputerShopComponent // extends ...

  constructor(props: ComputerShopProps) {
    super(props)
    this.state = {
      computerShop: { kind: "none" }

    }
  }

  async processApiComputerShopResponce(res: Response) {


    try {
      if (!res.ok)
        this.setState(s => ({ ...s, computerShop: { kind: "error-or-not-found" } }))

      let res1 = await res.json()

      this.setState(s => ({ ...s, computerShop: { kind: "loaded", value: res1 } }))
    }
    catch {
      this.setState(s => ({ ...s, computerShop: { kind: "error-or-not-found" } }))
    }
  }

  getComputerShop() {
    this.setState(s => ({ ...s, computerShop: { kind: "loading" } }), () => {

      let headers = { 'content-type': 'application/json' }
      //TODO 8 [1.0pt]: the following fetch to download all computer parts
      //...
        .then(async res => {
          this.processApiComputerShopResponce(res)
        })
    })
  }

  
  //TODO 9 [1.0pt]: start the downloading of the computer parts as soon as component is ready
  //...

  public render() {

    if (this.state.computerShop.kind != "loaded") {
      return <p>{this.state.computerShop.kind}</p>
    }


    return <div className='container-fluid row'>
      <div className="row">
        <div className='col-sm-6'>
          <h2>Computer Shop</h2>

          {this.state.computerShop.value.map(p =>
            <div style={{ border: "solid" }}>
              {/* TODO 10 [0.5pt] */}
              {/* render the PC details (use the right function component) */}
              <div>Computer: 
                {/* .... */}
              </div>
              <div>
                Parts:
                <div style={{ paddingLeft: 10 }}>
                  {/* TODO 11 [0.5pt] */}
                  {/* render the components details of the above PC (use the right function component) */}
                  {/* .... */}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  }
}