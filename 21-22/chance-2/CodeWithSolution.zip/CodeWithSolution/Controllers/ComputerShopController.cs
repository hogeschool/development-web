using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SimpleModelsAndRelations.Models;



namespace SimpleModelsAndRelations.Controllers
{

    [Route("[controller]")]
    public partial class ComputerShopController : Controller
    {
        private readonly ComputerShopContext _context;
        private readonly ProjectNameOptions _projectNameOptions;


        public ComputerShopController(ComputerShopContext context, IOptions<ProjectNameOptions> projectNameOptions)
        {
            _context = context;
            _projectNameOptions = projectNameOptions.Value;
            if (_context.PC.Count() == 0)
            {
                _context.PC.AddRange(new PC[]{
                    new PC(){Brand ="HP", Price=590, Model="X1ZP", Components=new List<Component>(){
                        new Component(){Kind="CPU", Brand="Intel", Specification="Core i9-12900K"},
                        new Component(){Kind="GPU", Brand="Radeon", Specification="RX 6600 XT"},
                        new Component(){Kind="RAM", Brand="Corsair", Specification="Vengeance 64GB"}

                    }},
                    new PC(){Brand ="Asus", Price=900, Model="GamersWP1", Components=new List<Component>(){
                        new Component(){Kind="CPU", Brand="AMD", Specification="Ryzen 5 3600"},
                        new Component(){Kind="GPU", Brand="GeForce", Specification="RTX 3060 Ti"},
                        new Component(){Kind="RAM", Brand="G. Skill", Specification="DDR4 Trident Z 32GB"}
                    }}
                });
                _context.SaveChanges();
            }
        }


        //TODO 4 [0.5pt]: complete the get below. Note that the path to this route is
        //...
        public IActionResult GetComputerParts()
        {

            var pc_components_tmp = (
                                        //TODO 5 [1.0pt]: join PC with Component
                                        //...
                                        select new { PC = p, Component = new { Id = c.Id, Brand = c.Brand, Kind = c.Kind, Specification = c.Specification } }).ToList();


            var pc_components = 
                //TODO 6 [1.5pt]: group "pc_components_tmp" so that the resulting collection looks like:
                //...


            return Ok(pc_components);
        }
    }
}
